import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class PublicService {
public name:string;
public password:string;
  constructor() { }
}
