export class CleanLevels {
   constructor
   ( 
        public LevelId:number,
        public CleanLevel:string
   ){}
}
