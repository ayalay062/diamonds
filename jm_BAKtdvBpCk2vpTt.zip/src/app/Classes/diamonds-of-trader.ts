export class DiamondsOfTrader {
    constructor(
        public diamondId: number,
        public diamondName: string,
        public cleanLevelId: number,
        public cleanLevelName: string,
        public colorId: number,
        public colorName: string,
        public shapeId: number,
        public shapeName: string,
        public CT: number) { }
}
