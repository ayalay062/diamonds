export class Food {
    constructor(public calories: number,
        public carbs: number,
        public fat: number,
        public name: string,
        public protein: number){}
}
