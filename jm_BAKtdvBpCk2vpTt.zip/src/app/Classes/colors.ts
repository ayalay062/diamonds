export class Colors {
    constructor(
        public ColorId:number,
        public Color:string
   ){}
}
