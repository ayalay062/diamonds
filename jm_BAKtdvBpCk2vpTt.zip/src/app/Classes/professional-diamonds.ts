export class ProfessionalDiamonds {
    constructor(
        public  traderId:number,
        public  traderLName:string,
        public  traderFName:string,
        public  diamondId:number ,
        public  diamondName:string,
        public  startDate:Date,
        public  startCT:number
    ){};
}
