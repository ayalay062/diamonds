export class Shapes {
    constructor(
        public shapeId:number,
        public shape:string
    ){}
}
