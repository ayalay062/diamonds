export class Professionales {
    public professionalId:number;
    public professionalName:string;
    public statusId:number; 
    public price:number;
    public userId:number;
}
