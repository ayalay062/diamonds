export class Hoby {

    constructor(public id:number, public name:string){}
}
