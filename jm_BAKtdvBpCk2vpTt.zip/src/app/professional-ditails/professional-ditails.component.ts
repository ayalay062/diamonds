import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-professional-ditails',
  templateUrl: './professional-ditails.component.html',
  styleUrls: ['./professional-ditails.component.css']
})
export class ProfessionalDitailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
